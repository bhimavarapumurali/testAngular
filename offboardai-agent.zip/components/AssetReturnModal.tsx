import React, { useState } from 'react';
import { X, Monitor, Save } from 'lucide-react';

interface AssetReturnModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: any) => void;
}

const AssetReturnModal: React.FC<AssetReturnModalProps> = ({ isOpen, onClose, onSubmit }) => {
    const [formData, setFormData] = useState({
        deviceType: 'Laptop',
        serialNumber: '',
        condition: 'Good',
        returnMethod: 'Drop-off at IT Desk'
    });

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md transform transition-all scale-100">
                <div className="flex justify-between items-center p-6 border-b border-gray-100">
                    <div className="flex items-center gap-2">
                        <div className="bg-indigo-100 p-2 rounded-lg">
                            <Monitor className="w-5 h-5 text-indigo-600" />
                        </div>
                        <div>
                            <h3 className="text-lg font-semibold text-gray-900">Asset Return</h3>
                            <p className="text-xs text-gray-500">ServiceNow Integration</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
                        <X className="w-5 h-5" />
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Device Type</label>
                        <select 
                            value={formData.deviceType}
                            onChange={(e) => setFormData({...formData, deviceType: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm"
                        >
                            <option>Laptop</option>
                            <option>Monitor</option>
                            <option>Mobile Phone</option>
                            <option>Security Badge</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Serial Number / Asset Tag</label>
                        <input 
                            type="text" 
                            required
                            value={formData.serialNumber}
                            onChange={(e) => setFormData({...formData, serialNumber: e.target.value})}
                            placeholder="e.g. LT-992834"
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Condition</label>
                        <div className="grid grid-cols-3 gap-2">
                            {['Excellent', 'Good', 'Damaged'].map((cond) => (
                                <button
                                    key={cond}
                                    type="button"
                                    onClick={() => setFormData({...formData, condition: cond})}
                                    className={`text-sm py-2 rounded-md border ${
                                        formData.condition === cond 
                                        ? 'bg-indigo-50 border-indigo-500 text-indigo-700 font-medium' 
                                        : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                                    }`}
                                >
                                    {cond}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Return Method</label>
                        <select 
                            value={formData.returnMethod}
                            onChange={(e) => setFormData({...formData, returnMethod: e.target.value})}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm"
                        >
                            <option>Drop-off at IT Desk</option>
                            <option>Mail-in (Request Label)</option>
                            <option>Manager Handover</option>
                        </select>
                    </div>

                    <div className="pt-4 flex gap-3">
                        <button 
                            type="button" 
                            onClick={onClose}
                            className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 font-medium text-sm hover:bg-gray-50 transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            type="submit" 
                            className="flex-1 px-4 py-2.5 bg-indigo-600 text-white rounded-lg font-medium text-sm hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-indigo-200"
                        >
                            <Save className="w-4 h-4" /> Submit Request
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AssetReturnModal;