import React, { useState, useEffect } from 'react';
import { INITIAL_TASKS } from './constants';
import { ChatMessage, OffboardingTask, LogEntry, TaskStatus } from './types';
import { chatWithGemini } from './services/geminiService';
import TaskList from './components/TaskList';
import AuditPanel from './components/AuditPanel';
import ChatInterface from './components/ChatInterface';
import AssetReturnModal from './components/AssetReturnModal';
import { Content, Part } from '@google/genai';

// Define API key availability check
const HAS_API_KEY = !!process.env.API_KEY;

const App: React.FC = () => {
    const [tasks, setTasks] = useState<OffboardingTask[]>(INITIAL_TASKS);
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [chatHistory, setChatHistory] = useState<Content[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [isAssetModalOpen, setIsAssetModalOpen] = useState(false);

    // Add Initial Welcome Message
    useEffect(() => {
        const welcomeText = "Hello! I'm your Offboarding Assistant. I can help you complete your checklist, answer policy questions, and guide you through the exit process. How can I help you today?";
        
        setMessages([{
            id: 'welcome',
            role: 'model',
            text: welcomeText
        }]);
        
        setChatHistory([{
            role: 'model',
            parts: [{ text: welcomeText }]
        }]);

        addLog('System initialized', 'Offboarding Agent session started', 'SYSTEM');
    }, []);

    const addLog = (action: string, details: string, actor: 'USER' | 'AGENT' | 'SYSTEM') => {
        setLogs(prev => [
            ...prev,
            { id: Date.now().toString(), timestamp: new Date(), action, details, actor }
        ]);
    };

    const handleUserMessage = async (text: string) => {
        if (!text.trim()) return;

        // 1. Update UI with User Message
        const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text };
        setMessages(prev => [...prev, userMsg]);
        addLog('Query Received', text, 'USER');
        setIsLoading(true);

        // 2. Prepare History
        let currentHistory: Content[] = [
            ...chatHistory,
            { role: 'user', parts: [{ text }] }
        ];

        try {
            let turns = 0;
            const MAX_TURNS = 5;
            let finalResponseText = "";

            // 3. Agent Loop (Model -> Tool -> Model)
            while (turns < MAX_TURNS) {
                const response = await chatWithGemini(currentHistory, tasks);
                const candidateContent = response.candidates?.[0]?.content;

                if (!candidateContent) throw new Error("No content from model");

                // Append model's turn to history (this could be text or a function call)
                currentHistory = [...currentHistory, candidateContent];
                
                const functionCalls = candidateContent.parts?.filter(p => p.functionCall);

                // If no function calls, we are done with this turn
                if (!functionCalls || functionCalls.length === 0) {
                    finalResponseText = candidateContent.parts?.find(p => p.text)?.text || "";
                    break;
                }

                // Process Function Calls
                const functionResponses: Part[] = [];
                
                for (const part of functionCalls) {
                    const call = part.functionCall!;
                    addLog('Tool Execution', `Agent calling tool: ${call.name}`, 'AGENT');
                    
                    let result: any = { result: 'Success' };

                    // --- Simulated Backend Logic ---
                    if (call.name === 'getTasks') {
                        result = { tasks };
                    } 
                    else if (call.name === 'markTaskCompleted') {
                        const args = call.args as any;
                        const taskId = args.taskId;
                        // Optimistic update
                        setTasks(prev => prev.map(t => 
                            t.id === taskId ? { ...t, status: TaskStatus.COMPLETED } : t
                        ));
                        addLog('Task Update', `Marked task ${taskId} as COMPLETED`, 'SYSTEM');
                        result = { message: `Task ${taskId} marked as completed.` };
                    }
                    else if (call.name === 'scheduleExitInterview') {
                        const args = call.args as any;
                        setTasks(prev => prev.map(t => 
                            t.title.includes('Exit Interview') ? { ...t, status: TaskStatus.IN_PROGRESS, description: `${t.description} (Scheduled for ${args.date} at ${args.time})` } : t
                        ));
                        addLog('Task Scheduled', `Exit Interview set for ${args.date}`, 'SYSTEM');
                        result = { message: `Interview scheduled for ${args.date}.` };
                    }
                    else if (call.name === 'openAssetReturnForm') {
                        setIsAssetModalOpen(true);
                        result = { message: 'Asset Return Form opened on screen.' };
                    }
                    // -------------------------------

                    functionResponses.push({
                        functionResponse: {
                            name: call.name,
                            response: result
                        }
                    });
                }

                // Append function results as a 'user' role turn (standard Gemini behavior)
                currentHistory = [...currentHistory, { role: 'user', parts: functionResponses }];
                turns++;
            }

            // 4. Update State with final history and UI message
            setChatHistory(currentHistory);
            
            if (finalResponseText) {
                setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: finalResponseText }]);
            } else if (turns > 0) {
                // Fallback if only actions performed but no text returned (rare)
                setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "I've processed your request." }]);
            }

        } catch (error) {
            console.error(error);
            setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', text: "I'm sorry, I encountered an error connecting to the HR System." }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleAssetFormSubmit = (data: any) => {
        setIsAssetModalOpen(false);
        // Update task status
        setTasks(prev => prev.map(t => 
            t.title.includes('Return IT') ? { ...t, status: TaskStatus.IN_PROGRESS } : t
        ));
        addLog('Form Submitted', `Asset Return Request: ${data.deviceType} (${data.serialNumber})`, 'USER');
        
        const confirmationText = `Thank you. I've submitted your return request for the ${data.deviceType} (${data.serialNumber}). You will receive a shipping label via email shortly.`;
        
        setMessages(prev => [...prev, { 
            id: Date.now().toString(), 
            role: 'model', 
            text: confirmationText 
        }]);
        
        // Also update history to keep context
        setChatHistory(prev => [...prev, { role: 'model', parts: [{ text: confirmationText }] }]);
    };

    if (!HAS_API_KEY) {
        return (
             <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="bg-white p-8 rounded-xl shadow-md max-w-md text-center">
                    <h1 className="text-2xl font-bold text-red-600 mb-4">API Key Missing</h1>
                    <p className="text-gray-600 mb-6">Please configure the <code>API_KEY</code> environment variable to use the Gemini-powered Offboarding Agent.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#f3f4f6] p-4 md:p-8 font-sans">
            <div className="max-w-7xl mx-auto h-[calc(100vh-4rem)] flex flex-col md:flex-row gap-6">
                
                {/* LEFT COLUMN - CHAT */}
                <div className="w-full md:w-2/3 h-full">
                    <ChatInterface 
                        messages={messages} 
                        isLoading={isLoading} 
                        onSendMessage={handleUserMessage} 
                    />
                </div>

                {/* RIGHT COLUMN - DASHBOARD */}
                <div className="w-full md:w-1/3 flex flex-col gap-6 h-full overflow-hidden">
                    {/* Progress Card */}
                    <div className="bg-gradient-to-r from-indigo-600 to-blue-600 rounded-xl p-6 text-white shadow-lg">
                        <h2 className="text-lg font-semibold mb-1">Departure Status</h2>
                        <div className="flex items-end gap-2 mb-2">
                            <span className="text-4xl font-bold">
                                {Math.round((tasks.filter(t => t.status === TaskStatus.COMPLETED).length / tasks.length) * 100)}%
                            </span>
                            <span className="text-indigo-100 mb-1.5">Completed</span>
                        </div>
                        <div className="w-full bg-black/20 rounded-full h-2">
                            <div 
                                className="bg-white h-2 rounded-full transition-all duration-500" 
                                style={{ width: `${(tasks.filter(t => t.status === TaskStatus.COMPLETED).length / tasks.length) * 100}%` }}
                            ></div>
                        </div>
                        <p className="text-xs text-indigo-100 mt-3">Last Day: Oct 30, 2023 (3 Days remaining)</p>
                    </div>

                    {/* Task List */}
                    <div className="flex-1 overflow-hidden flex flex-col">
                        <TaskList tasks={tasks} />
                    </div>

                    {/* Audit Log */}
                    <div className="h-1/3 min-h-[200px]">
                        <AuditPanel logs={logs} />
                    </div>
                </div>
            </div>

            {/* Modals */}
            <AssetReturnModal 
                isOpen={isAssetModalOpen} 
                onClose={() => setIsAssetModalOpen(false)}
                onSubmit={handleAssetFormSubmit}
            />
        </div>
    );
};

export default App;