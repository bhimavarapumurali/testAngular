import React from 'react';
import { LogEntry } from '../types';
import { FileText, Bot, User, Settings } from 'lucide-react';

interface AuditPanelProps {
    logs: LogEntry[];
}

const AuditPanel: React.FC<AuditPanelProps> = ({ logs }) => {
    const getIcon = (actor: string) => {
        switch (actor) {
            case 'AGENT': return <Bot className="w-3 h-3" />;
            case 'USER': return <User className="w-3 h-3" />;
            default: return <Settings className="w-3 h-3" />;
        }
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden mt-6 flex flex-col h-[300px]">
            <div className="p-3 border-b border-gray-100 bg-gray-50 flex items-center gap-2">
                <FileText className="w-4 h-4 text-gray-500" />
                <h3 className="font-semibold text-sm text-gray-800">Audit Log & Traceability</h3>
            </div>
            <div className="overflow-y-auto p-4 space-y-4 flex-1">
                {logs.length === 0 && (
                    <p className="text-center text-xs text-gray-400 mt-4">No activities recorded yet.</p>
                )}
                {logs.slice().reverse().map((log) => (
                    <div key={log.id} className="flex gap-3">
                        <div className="flex flex-col items-center">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-[10px] ${
                                log.actor === 'AGENT' ? 'bg-purple-500' : log.actor === 'USER' ? 'bg-blue-500' : 'bg-gray-500'
                            }`}>
                                {getIcon(log.actor)}
                            </div>
                            <div className="w-0.5 flex-1 bg-gray-100 my-1 last:hidden"></div>
                        </div>
                        <div className="pb-2">
                            <p className="text-xs font-medium text-gray-900">{log.action}</p>
                            <p className="text-[11px] text-gray-500 mt-0.5">{log.details}</p>
                            <p className="text-[10px] text-gray-400 mt-1">
                                {log.timestamp.toLocaleTimeString()} - {log.timestamp.toLocaleDateString()}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default AuditPanel;