import React from 'react';
import { OffboardingTask, TaskStatus, Platform } from '../types';
import { CheckCircle, Circle, Clock, AlertCircle, ExternalLink } from 'lucide-react';

interface TaskListProps {
    tasks: OffboardingTask[];
}

const TaskList: React.FC<TaskListProps> = ({ tasks }) => {
    const getStatusIcon = (status: TaskStatus) => {
        switch (status) {
            case TaskStatus.COMPLETED: return <CheckCircle className="w-5 h-5 text-green-500" />;
            case TaskStatus.IN_PROGRESS: return <Clock className="w-5 h-5 text-blue-500" />;
            case TaskStatus.OVERDUE: return <AlertCircle className="w-5 h-5 text-red-500" />;
            default: return <Circle className="w-5 h-5 text-gray-300" />;
        }
    };

    const getPlatformBadge = (platform: Platform) => {
        const colors = {
            [Platform.WORKDAY]: 'bg-blue-100 text-blue-800',
            [Platform.SERVICENOW]: 'bg-purple-100 text-purple-800',
            [Platform.TEAMS]: 'bg-indigo-100 text-indigo-800',
            [Platform.OFFLINE]: 'bg-gray-100 text-gray-800',
        };
        return (
            <span className={`text-xs font-medium px-2 py-0.5 rounded ${colors[platform]}`}>
                {platform}
            </span>
        );
    };

    return (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                <h3 className="font-semibold text-gray-800">My Offboarding Checklist</h3>
                <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded border border-gray-200">
                    {tasks.filter(t => t.status === TaskStatus.COMPLETED).length} / {tasks.length} Completed
                </span>
            </div>
            <div className="divide-y divide-gray-100 max-h-[400px] overflow-y-auto">
                {tasks.map(task => (
                    <div key={task.id} className="p-4 hover:bg-gray-50 transition-colors group">
                        <div className="flex items-start gap-3">
                            <div className="mt-0.5 flex-shrink-0">
                                {getStatusIcon(task.status)}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-start">
                                    <p className={`text-sm font-medium truncate ${task.status === TaskStatus.COMPLETED ? 'text-gray-400 line-through' : 'text-gray-900'}`}>
                                        {task.title}
                                    </p>
                                    {getPlatformBadge(task.platform)}
                                </div>
                                <p className="text-xs text-gray-500 mt-1 line-clamp-2">{task.description}</p>
                                <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                                    <span>Due: {task.dueDate}</span>
                                    {task.status !== TaskStatus.COMPLETED && (
                                        <button className="text-blue-600 hover:text-blue-800 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                            Open in {task.platform} <ExternalLink className="w-3 h-3" />
                                        </button>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default TaskList;