export enum TaskStatus {
    PENDING = 'PENDING',
    IN_PROGRESS = 'IN_PROGRESS',
    COMPLETED = 'COMPLETED',
    OVERDUE = 'OVERDUE'
}

export enum Platform {
    WORKDAY = 'Workday',
    SERVICENOW = 'ServiceNow',
    TEAMS = 'Microsoft Teams',
    OFFLINE = 'In Person'
}

export interface OffboardingTask {
    id: string;
    title: string;
    description: string;
    status: TaskStatus;
    platform: Platform;
    dueDate: string;
}

export interface KnowledgeArticle {
    id: string;
    title: string;
    category: string;
    content: string;
    links?: string[];
}

export interface LogEntry {
    id: string;
    timestamp: Date;
    action: string;
    details: string;
    actor: 'USER' | 'AGENT' | 'SYSTEM';
}

export interface ChatMessage {
    id: string;
    role: 'user' | 'model' | 'system';
    text: string;
    isToolCall?: boolean;
    toolCallId?: string;
}

export interface AssetReturnFormData {
    deviceType: string;
    serialNumber: string;
    condition: string;
    returnMethod: string;
}