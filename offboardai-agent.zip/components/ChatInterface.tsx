import React, { useEffect, useRef, useState } from 'react';
import { Send, Bot, User, Sparkles, Paperclip, Mic } from 'lucide-react';
import { ChatMessage } from '../types';
import ReactMarkdown from 'react-markdown';

interface ChatInterfaceProps {
    messages: ChatMessage[];
    isLoading: boolean;
    onSendMessage: (text: string) => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, isLoading, onSendMessage }) => {
    const [input, setInput] = useState('');
    const bottomRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages, isLoading]);

    const handleSend = () => {
        if (!input.trim()) return;
        onSendMessage(input);
        setInput('');
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    return (
        <div className="flex flex-col h-full bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            {/* Header */}
            <div className="p-4 border-b border-gray-100 bg-white flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-blue-500 rounded-full flex items-center justify-center shadow-lg shadow-indigo-200">
                        <Bot className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <h2 className="font-bold text-gray-800">OffboardAI Assistant</h2>
                        <p className="text-xs text-green-600 flex items-center gap-1">
                            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                            Online • HR Knowledge Base Active
                        </p>
                    </div>
                </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-gray-50/50">
                {messages.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full text-center space-y-4 opacity-60">
                        <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mb-2">
                            <Sparkles className="w-8 h-8 text-indigo-400" />
                        </div>
                        <h3 className="text-lg font-semibold text-gray-700">How can I help you today?</h3>
                        <div className="flex flex-wrap justify-center gap-2 max-w-md">
                            {['How do I return my laptop?', 'Schedule my exit interview', 'When is my last paycheck?', 'What about my 401k?'].map(q => (
                                <button 
                                    key={q}
                                    onClick={() => onSendMessage(q)}
                                    className="text-sm bg-white border border-gray-200 px-3 py-1.5 rounded-full text-gray-600 hover:bg-indigo-50 hover:border-indigo-200 transition-colors"
                                >
                                    {q}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {messages.map((msg) => (
                    <div key={msg.id} className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center ${
                            msg.role === 'user' ? 'bg-gray-800' : 'bg-indigo-600'
                        }`}>
                            {msg.role === 'user' ? <User className="w-5 h-5 text-white" /> : <Bot className="w-5 h-5 text-white" />}
                        </div>
                        
                        <div className={`flex flex-col max-w-[80%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                            <div className={`px-5 py-3.5 rounded-2xl shadow-sm text-sm leading-relaxed ${
                                msg.role === 'user' 
                                ? 'bg-gray-800 text-white rounded-tr-none' 
                                : 'bg-white text-gray-700 border border-gray-100 rounded-tl-none'
                            }`}>
                                <ReactMarkdown 
                                    components={{
                                        a: ({node, ...props}) => <a {...props} className="text-blue-600 hover:underline font-medium" target="_blank" rel="noopener noreferrer" />
                                    }}
                                >
                                    {msg.text}
                                </ReactMarkdown>
                            </div>
                            {msg.role === 'model' && (
                                <span className="text-[10px] text-gray-400 mt-1 ml-1">AI Generated • {new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                            )}
                        </div>
                    </div>
                ))}
                
                {isLoading && (
                    <div className="flex gap-4">
                        <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center">
                            <Bot className="w-5 h-5 text-white" />
                        </div>
                        <div className="bg-white border border-gray-100 px-5 py-4 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-2">
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                        </div>
                    </div>
                )}
                <div ref={bottomRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 bg-white border-t border-gray-100">
                <div className="relative flex items-center">
                    <div className="absolute left-3 flex items-center gap-2 text-gray-400">
                        <button className="hover:text-indigo-500 transition-colors"><Paperclip className="w-5 h-5" /></button>
                    </div>
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Type your question or request..."
                        className="w-full pl-12 pr-12 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none text-gray-700 placeholder-gray-400 transition-all"
                        disabled={isLoading}
                    />
                    <div className="absolute right-3 flex items-center gap-2">
                        {input.trim() ? (
                            <button 
                                onClick={handleSend}
                                className="p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-all shadow-md shadow-indigo-200"
                            >
                                <Send className="w-4 h-4" />
                            </button>
                        ) : (
                             <button className="p-2 text-gray-400 hover:text-gray-600">
                                <Mic className="w-5 h-5" />
                            </button>
                        )}
                    </div>
                </div>
                <p className="text-center text-xs text-gray-400 mt-3">
                    AI Agent can make mistakes. Please verify critical HR information.
                </p>
            </div>
        </div>
    );
};

export default ChatInterface;