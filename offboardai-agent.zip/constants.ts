import { KnowledgeArticle, OffboardingTask, Platform, TaskStatus } from "./types";

export const INITIAL_TASKS: OffboardingTask[] = [
    {
        id: 't1',
        title: 'Submit Resignation in Workday',
        description: 'Formally submit your resignation request via the Workday portal.',
        status: TaskStatus.COMPLETED,
        platform: Platform.WORKDAY,
        dueDate: '2023-10-01'
    },
    {
        id: 't2',
        title: 'Complete Exit Interview',
        description: 'Schedule and complete the exit interview with HR.',
        status: TaskStatus.PENDING,
        platform: Platform.WORKDAY,
        dueDate: '2023-10-25'
    },
    {
        id: 't3',
        title: 'Return IT Assets',
        description: 'Return laptop, badge, and peripherals to the IT Desk.',
        status: TaskStatus.PENDING,
        platform: Platform.SERVICENOW,
        dueDate: '2023-10-27'
    },
    {
        id: 't4',
        title: 'Transfer Knowledge Base',
        description: 'Upload all project documents to the team SharePoint.',
        status: TaskStatus.IN_PROGRESS,
        platform: Platform.TEAMS,
        dueDate: '2023-10-26'
    },
    {
        id: 't5',
        title: 'Review Benefits Continuation',
        description: 'Review COBRA and health insurance continuation documents.',
        status: TaskStatus.PENDING,
        platform: Platform.WORKDAY,
        dueDate: '2023-10-28'
    }
];

export const KNOWLEDGE_BASE: KnowledgeArticle[] = [
    {
        id: 'kb1',
        title: 'IT Asset Return Policy',
        category: 'IT',
        content: 'All employees must return their laptops, chargers, monitors, and security badges on or before their last day of employment. Returns can be made in person at the IT Helpdesk on the 2nd floor, or via a pre-paid shipping label requested through ServiceNow. Failure to return assets may result in a deduction from the final paycheck.',
        links: ['https://servicenow.mock/asset-return']
    },
    {
        id: 'kb2',
        title: 'Exit Interview Process',
        category: 'HR',
        content: 'The Exit Interview is a mandatory step for all employees level L4 and above. It is a confidential conversation to gather feedback on your experience. It can be scheduled via Workday or directly with your HRBP. Please complete the pre-interview survey sent to your email 3 days prior to your last day.',
        links: ['https://workday.mock/exit-interview']
    },
    {
        id: 'kb3',
        title: 'Final Paycheck & Benefits',
        category: 'Payroll',
        content: 'Your final paycheck will be processed in the next regular pay cycle following your termination date. It will include payment for all hours worked and any accrued but unused vacation time (if applicable by state law). Health benefits coverage ends on the last day of the month in which you terminate. COBRA information will be mailed to your home address.',
    },
    {
        id: 'kb4',
        title: 'Data Handover Guidelines',
        category: 'Compliance',
        content: 'Ensure all personal files are removed from company devices. Transfer ownership of Google Drive folders and Calendar events to your manager. Do not forward company emails to personal accounts as this violates the DLP policy.',
    },
    {
        id: 'kb5',
        title: 'Laptop Buyout Program',
        category: 'IT',
        content: 'Employees with devices older than 3 years may be eligible to purchase them at fair market value. Request a quote via the IT Portal before your last day.',
        links: ['https://servicenow.mock/buyout']
    },
    {
        id: 'kb6',
        title: 'Garden Leave Policy',
        category: 'HR',
        content: 'If you are joining a competitor, you may be placed on Garden Leave. Access to systems will be revoked immediately, but you will remain on payroll for the notice period. You must not contact clients during this time.',
    }
];

export const SYSTEM_INSTRUCTION = `You are OffboardAI, a helpful and professional HR Offboarding Assistant.
Your goal is to guide employees through their offboarding process, answer questions using the provided Knowledge Base context, and help them manage their tasks.

You have access to the user's current task list and can modify it using tools.
You have access to a Knowledge Base (provided in context). ALWAYS use this context to answer policy questions. If the answer is not in the context, politely say you don't have that specific information and suggest contacting HR directly.

Tone: Empathetic, professional, clear, and concise.
When a user says they have done something, use the 'markTaskCompleted' tool to update their status.
When a user asks to schedule something, use the 'scheduleTask' tool.
When a user asks about asset returns, guide them to the 'submitAssetReturn' tool if appropriate.

Format links using Markdown: [Link Text](url).
`;