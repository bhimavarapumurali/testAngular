import { GoogleGenAI, FunctionDeclaration, Type, Tool, Content, GenerateContentResponse } from "@google/genai";
import { KNOWLEDGE_BASE, SYSTEM_INSTRUCTION } from "../constants";
import { OffboardingTask } from "../types";

// Initialize Gemini Client
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// --- Tool Definitions ---

const getTasksTool: FunctionDeclaration = {
    name: 'getTasks',
    description: 'Retrieve the current list of offboarding tasks and their status.',
    parameters: { type: Type.OBJECT, properties: {} },
};

const markTaskCompletedTool: FunctionDeclaration = {
    name: 'markTaskCompleted',
    description: 'Mark a specific offboarding task as completed. Use this when the user confirms they have finished a task.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            taskId: { type: Type.STRING, description: 'The ID of the task to complete (e.g., t1, t2).' },
            notes: { type: Type.STRING, description: 'Optional notes about completion.' }
        },
        required: ['taskId']
    },
};

const scheduleExitInterviewTool: FunctionDeclaration = {
    name: 'scheduleExitInterview',
    description: 'Schedule the exit interview task. Updates the task status to IN_PROGRESS.',
    parameters: {
        type: Type.OBJECT,
        properties: {
            date: { type: Type.STRING, description: 'The preferred date for the interview.' },
            time: { type: Type.STRING, description: 'The preferred time.' }
        },
        required: ['date']
    },
};

const openAssetReturnFormTool: FunctionDeclaration = {
    name: 'openAssetReturnForm',
    description: 'Triggers the UI to open the Asset Return Form modal. Use this when the user wants to return equipment or asks how to return assets.',
    parameters: { type: Type.OBJECT, properties: {} },
};

const tools: Tool[] = [{
    functionDeclarations: [
        getTasksTool,
        markTaskCompletedTool,
        scheduleExitInterviewTool,
        openAssetReturnFormTool
    ]
}];

// --- RAG Context Injection ---
const getContextString = () => {
    return KNOWLEDGE_BASE.map(article => 
        `Title: ${article.title}\nCategory: ${article.category}\nContent: ${article.content}\nLinks: ${article.links?.join(', ') || 'None'}`
    ).join('\n\n');
};

export const chatWithGemini = async (
    history: Content[],
    currentTasks: OffboardingTask[]
): Promise<GenerateContentResponse> => {
    const model = 'gemini-2.5-flash'; 
    
    // Construct a rich system instruction with dynamic state context
    const dynamicContext = `
    CURRENT KNOWLEDGE BASE CONTEXT:
    ${getContextString()}

    CURRENT USER TASKS STATUS:
    ${JSON.stringify(currentTasks, null, 2)}
    `;

    const fullSystemInstruction = `${SYSTEM_INSTRUCTION}\n\n${dynamicContext}`;

    try {
        const response = await ai.models.generateContent({
            model,
            contents: history,
            config: {
                systemInstruction: fullSystemInstruction,
                tools: tools,
                temperature: 0.4,
            }
        });

        return response;
    } catch (error) {
        console.error("Gemini API Error:", error);
        throw error;
    }
};